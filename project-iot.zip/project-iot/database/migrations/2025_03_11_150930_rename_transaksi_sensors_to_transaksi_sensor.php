<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::rename('transaksi_sensors', 'transaksi_sensor');
    }

    public function down() {
        Schema::rename('transaksi_sensor', 'transaksi_sensors');
    }
};

